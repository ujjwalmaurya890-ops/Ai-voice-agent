# CampusVoice

A Windows desktop voice study partner built on the **Gemini Live API** (Google GenAI SDK, Python).
Talk to it, interrupt it mid-sentence, and let it keep your tasks and notes by voice.

## What it does

- Real-time two-way voice with **barge-in**: when you start talking, the server cancels the reply and the app flushes queued speech immediately.
- Study tools the model can call: add/list/complete tasks with deadlines, save/search notes, get today's date.
- Live transcript of both sides, a task list panel, mute, and a typed-message box.
- Sessions longer than 15 minutes: context window compression and session resumption are enabled, and the app reconnects with the last resume handle when the server sends GoAway.

## Model IDs (checked 2026-10-16 against ai.google.dev/gemini-api/docs/models)

| Use | Model ID |
|---|---|
| Default (low latency voice) | `gemini-3.8-live` |
| Slower, more reasoning (set `CAMPUSVOICE_MODEL`) | `gemini-3.8-live-extended-thinking` |
| Legacy, avoid | `gemini-3.1-flash-live-preview` |

Google's page says to use `gemini-3.8-live` for most voice agents. If connecting ever fails with "model not found", re-check that page and edit `campusvoice/config.py`.

## Windows setup (about 10 minutes)

1. **Install Python 3.11 or newer** from https://www.python.org/downloads/windows/ . On the first installer screen tick **Add python.exe to PATH**. Keep the default options (this includes Tkinter, which the window needs).
2. **Get a Gemini API key** at https://aistudio.google.com/apikey . Live API usage is billed, so check the pricing page for your account.
3. **Unzip** this folder anywhere, e.g. `C:\Users\you\campusvoice-ai`. Open it in File Explorer.
4. **Double-click `setup.bat`.** It creates a `.venv` and installs the packages.
5. **Double-click `test.bat`.** Expect `35 passed`. These tests need no key and no microphone.
6. **Give the app your key**, either way:
   - Open the app (step 8) and click **API key...**. The key goes into Windows Credential Manager, never a file. Or
   - In Command Prompt: `setx GEMINI_API_KEY "paste-key-here"`, then close and reopen the window. The environment variable wins over the saved key.
7. **Double-click `check.bat`.** It confirms the key is found (value hidden), lists audio devices, and does one real Live API call that should print `received N.Ns of audio`. This is the first test that touches Google and your sound hardware.
8. **Double-click `run.bat`.** Click **Start**, wait for "Listening", and talk.

If Windows blocks the mic: Settings > Privacy & security > Microphone > turn on **Let desktop apps access your microphone**.

**Use headphones.** With speakers, the mic hears the model and the server may treat that as you interrupting. If you must use speakers, set `CAMPUSVOICE_HALF_DUPLEX=1` (the app stops listening while it speaks, so barge-in is off).

## Try saying

- "Explain how a hash table handles collisions, then quiz me."
- "Add a task: finish the OS lab report, due next Friday."
- "What's on my list?" / "Mark task 2 done."
- "Save a note: TCP handshake is SYN, SYN-ACK, ACK."
- "Plan a 2 hour study block for my algorithms midterm."

## Settings (environment variables, all optional)

| Variable | Meaning |
|---|---|
| `GEMINI_API_KEY` / `GOOGLE_API_KEY` | API key (checked in that order, before Credential Manager) |
| `CAMPUSVOICE_MODEL` | Live model ID |
| `CAMPUSVOICE_VOICE` | Prebuilt voice name, default `Kore` |
| `CAMPUSVOICE_HALF_DUPLEX` | `1` = don't send mic audio while the model speaks |
| `CAMPUSVOICE_DATA_DIR` | Where tasks, notes and the log live. Default `%APPDATA%\CampusVoice` |

## How the key is protected

- Never stored in the project, `.env`, or any plain file. Source is env var or Windows Credential Manager (`keyring`).
- Never printed. Error text and log lines pass through a scrubber that removes the key and `key=...` URL fragments.
- `check.bat` and the UI only say where a key was found, not its value.

## Project layout

```
campusvoice/
  config.py        model IDs, audio constants, VAD settings, system prompt
  secure_key.py    key lookup/storage and redaction
  tools.py         tasks/notes store and the function declarations
  audio.py         mic capture, speaker playback, flushable buffer
  live_session.py  Live config, message handler, reconnect loop, thread facade
  transcript.py    groups transcript fragments into lines
  gui.py           Tkinter window
  diagnostics.py   check.bat backend
tests/             35 pytest tests (fake Live server, real SDK types)
setup.bat run.bat test.bat check.bat
```

## What was and wasn't verified

Verified in a Linux sandbox with Python 3.12 and google-genai 2.31.0: all 35 tests, including simulated sessions covering interruption, tool calls, transcripts, resume-on-reconnect, give-up with key redaction, mute, half-duplex, and typed text. Configs and messages are built from the real SDK classes, so a wrong field name fails there.

**Not verified by me**: real Windows audio devices, a real connection to Gemini, and the Tkinter window (it only passed a syntax check; the sandbox has no Tk). `check.bat` covers the first two on your machine; the window is the third. If something misbehaves, send me the text from `%APPDATA%\CampusVoice\campusvoice.log`.

## Troubleshooting

- **No sound / no mic**: run `check.bat`, read the device list, and set Windows default input/output devices. `AudioIO` accepts `input_device`/`output_device` indexes if you need to pick one explicitly.
- **It interrupts itself**: speaker echo. Use headphones.
- **"Could not keep a connection"**: wrong key, no internet, or the model ID is unavailable to your account.
- **Replies feel cut off after a pause**: raise `VAD_SILENCE_MS` in `config.py` (Google recommends 500-800 ms).

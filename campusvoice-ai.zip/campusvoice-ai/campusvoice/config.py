"""Central configuration. No secrets live in this file."""
from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "CampusVoice"

# Model IDs checked against https://ai.google.dev/gemini-api/docs/models
# (page last updated 2026-10-13). Re-check that page if a connect call fails
# with "model not found", because Live model names change faster than SDKs.
MODEL_DEFAULT = "gemini-3.8-live"  # default low-latency voice model
MODEL_EXTENDED = "gemini-3.8-live-extended-thinking"  # slower, reasons more
MODEL_LEGACY = "gemini-3.1-flash-live-preview"  # legacy preview, avoid

MODEL_ID = os.environ.get("CAMPUSVOICE_MODEL", MODEL_DEFAULT)
VOICE_NAME = os.environ.get("CAMPUSVOICE_VOICE", "Kore")

# Audio formats required by the Live API: 16 kHz in, 24 kHz out, 16-bit mono PCM.
INPUT_SAMPLE_RATE = 16_000
OUTPUT_SAMPLE_RATE = 24_000
MIC_BLOCK_FRAMES = 800  # 50 ms of microphone audio per chunk
SPEAKER_BLOCK_FRAMES = 1024  # about 43 ms, keeps barge-in latency low

# Server-side voice activity detection. The docs recommend 500-800 ms of
# silence so natural pauses are not split into fragments.
VAD_SILENCE_MS = 600
VAD_PREFIX_PADDING_MS = 100

# Set CAMPUSVOICE_HALF_DUPLEX=1 to stop sending mic audio while the model is
# speaking. This prevents speaker echo from self-interrupting, but it also
# disables barge-in. Prefer headphones and leave this off.
HALF_DUPLEX = os.environ.get("CAMPUSVOICE_HALF_DUPLEX", "0") == "1"

SYSTEM_PROMPT = """\
You are CampusVoice, a voice study partner for a college student.

Speak naturally and briefly: one to three sentences per turn unless the student \
asks you to go deeper. You are speaking aloud, so never read out markdown, \
symbols, or long lists.

Priorities:
1. Explain concepts clearly with one concrete example, then check understanding \
with one short question.
2. When asked, quiz the student one question at a time, wait for the answer, \
then give feedback.
3. Help plan study sessions in small steps (for example 25 minutes of focus, \
5 minutes of break) and keep track of deadlines.

Tools: use add_task for deadlines and to-dos, list_tasks and complete_task to \
manage them, save_note for short summaries or flashcard-style facts the student \
wants kept, search_notes to recall them, and get_current_datetime to resolve \
words like "tomorrow" or "Friday". Confirm out loud after you change the task \
list. Never invent tasks or notes; read them from the tools.

Be honest about uncertainty. Do not make up citations, formulas, or details \
about the student's syllabus or professor. If the student wants graded work \
done for them, help them learn it instead: outlines, hints, and feedback on \
their own drafts.

If the student interrupts, stop and listen. Reply in the language the student \
speaks.
"""


def data_dir() -> Path:
    """Folder for tasks, notes and logs. Windows: %APPDATA%\\CampusVoice."""
    override = os.environ.get("CAMPUSVOICE_DATA_DIR")
    if override:
        path = Path(override)
    elif os.environ.get("APPDATA"):
        path = Path(os.environ["APPDATA"]) / APP_NAME
    else:
        path = Path.home() / ".campusvoice"
    path.mkdir(parents=True, exist_ok=True)
    return path

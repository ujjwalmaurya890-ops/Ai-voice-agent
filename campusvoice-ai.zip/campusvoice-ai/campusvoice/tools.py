"""Study tools the model can call: tasks, notes, and the current date.

Data lives in a local JSON file (default %APPDATA%\\CampusVoice\\study_data.json).
Writes are atomic so a crash cannot corrupt the file.
"""
from __future__ import annotations

import json
import os
import threading
from datetime import date, datetime
from pathlib import Path
from typing import Any, Optional

from google.genai import types

from . import config

MAX_TITLE = 200
MAX_NOTE = 4000


class ToolError(ValueError):
    """Raised for bad tool arguments; the message is sent back to the model."""


class StudyStore:
    def __init__(self, path: Optional[Path] = None) -> None:
        self._path = Path(path) if path else config.data_dir() / "study_data.json"
        self._lock = threading.Lock()
        self._data: dict[str, Any] = {"next_id": 1, "tasks": [], "notes": []}
        self._load()

    # ---- persistence -------------------------------------------------
    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            loaded = json.loads(self._path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                self._data.update(loaded)
        except (OSError, json.JSONDecodeError):
            backup = self._path.with_suffix(".corrupt.json")
            try:
                os.replace(self._path, backup)
            except OSError:
                pass

    def _save(self) -> None:
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
        os.replace(tmp, self._path)

    # ---- tasks -------------------------------------------------------
    def add_task(
        self, title: str, due_date: Optional[str] = None, course: Optional[str] = None
    ) -> dict[str, Any]:
        title = _clean(title, MAX_TITLE, "title")
        due = None
        if due_date:
            try:
                due = date.fromisoformat(due_date).isoformat()
            except ValueError as exc:
                raise ToolError("due_date must look like 2026-10-31.") from exc
        with self._lock:
            task = {
                "id": self._data["next_id"],
                "title": title,
                "due_date": due,
                "course": (course or "").strip()[:80] or None,
                "done": False,
                "created": datetime.now().isoformat(timespec="seconds"),
            }
            self._data["next_id"] += 1
            self._data["tasks"].append(task)
            self._save()
            return dict(task)

    def list_tasks(self, include_completed: bool = False) -> list[dict[str, Any]]:
        with self._lock:
            tasks = [
                dict(t) for t in self._data["tasks"] if include_completed or not t["done"]
            ]
        tasks.sort(key=lambda t: (t["due_date"] is None, t["due_date"] or "", t["id"]))
        return tasks

    def complete_task(self, task_id: int) -> dict[str, Any]:
        with self._lock:
            for task in self._data["tasks"]:
                if task["id"] == task_id:
                    task["done"] = True
                    self._save()
                    return dict(task)
        raise ToolError(f"No task with id {task_id}.")

    # ---- notes -------------------------------------------------------
    def save_note(
        self, title: str, content: str, course: Optional[str] = None
    ) -> dict[str, Any]:
        title = _clean(title, MAX_TITLE, "title")
        content = _clean(content, MAX_NOTE, "content")
        with self._lock:
            note = {
                "id": self._data["next_id"],
                "title": title,
                "content": content,
                "course": (course or "").strip()[:80] or None,
                "created": datetime.now().isoformat(timespec="seconds"),
            }
            self._data["next_id"] += 1
            self._data["notes"].append(note)
            self._save()
            return dict(note)

    def search_notes(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        words = [w for w in (query or "").lower().split() if w]
        if not words:
            raise ToolError("query must not be empty.")
        with self._lock:
            notes = [dict(n) for n in self._data["notes"]]
        scored = []
        for note in notes:
            haystack = f"{note['title']} {note['content']} {note['course'] or ''}".lower()
            score = sum(haystack.count(w) for w in words)
            if score:
                scored.append((score, note))
        scored.sort(key=lambda pair: (-pair[0], -pair[1]["id"]))
        return [n for _, n in scored[:limit]]


def _clean(value: Any, limit: int, field: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ToolError(f"{field} must not be empty.")
    return text[:limit]


# ---- declarations sent to the model ----------------------------------
TOOL_DECLARATIONS: list[dict[str, Any]] = [
    {
        "name": "add_task",
        "description": "Add a study task or deadline to the student's list.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {"type": "STRING", "description": "Short task title."},
                "due_date": {
                    "type": "STRING",
                    "description": "Due date as YYYY-MM-DD. Omit if none.",
                },
                "course": {"type": "STRING", "description": "Course name or code."},
            },
            "required": ["title"],
        },
    },
    {
        "name": "list_tasks",
        "description": "List the student's tasks, soonest deadline first.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "include_completed": {
                    "type": "BOOLEAN",
                    "description": "Also include finished tasks.",
                }
            },
        },
    },
    {
        "name": "complete_task",
        "description": "Mark a task as done using its numeric id from list_tasks.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"task_id": {"type": "INTEGER", "description": "Task id."}},
            "required": ["task_id"],
        },
    },
    {
        "name": "save_note",
        "description": "Save a short study note or flashcard-style fact.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {"type": "STRING"},
                "content": {"type": "STRING", "description": "The note text."},
                "course": {"type": "STRING"},
            },
            "required": ["title", "content"],
        },
    },
    {
        "name": "search_notes",
        "description": "Search saved notes by keywords.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"query": {"type": "STRING", "description": "Keywords."}},
            "required": ["query"],
        },
    },
    {
        "name": "get_current_datetime",
        "description": "Get today's local date, weekday and time.",
        "parameters": {"type": "OBJECT", "properties": {}},
    },
]

MUTATING_TOOLS = {"add_task", "complete_task", "save_note"}


def build_tools() -> list[types.Tool]:
    return [
        types.Tool(
            function_declarations=[
                types.FunctionDeclaration(**decl) for decl in TOOL_DECLARATIONS
            ]
        )
    ]


def execute_tool(store: StudyStore, name: str, args: Optional[dict[str, Any]]) -> dict[str, Any]:
    """Run a tool call. Always returns a dict: {"result": ...} or {"error": ...}."""
    args = dict(args or {})
    try:
        if name == "add_task":
            return {"result": store.add_task(args.get("title", ""), args.get("due_date"), args.get("course"))}
        if name == "list_tasks":
            return {"result": store.list_tasks(bool(args.get("include_completed", False)))}
        if name == "complete_task":
            try:
                task_id = int(args.get("task_id"))
            except (TypeError, ValueError) as exc:
                raise ToolError("task_id must be a whole number.") from exc
            return {"result": store.complete_task(task_id)}
        if name == "save_note":
            return {"result": store.save_note(args.get("title", ""), args.get("content", ""), args.get("course"))}
        if name == "search_notes":
            return {"result": store.search_notes(args.get("query", ""))}
        if name == "get_current_datetime":
            now = datetime.now().astimezone()
            return {
                "result": {
                    "date": now.date().isoformat(),
                    "weekday": now.strftime("%A"),
                    "time": now.strftime("%H:%M"),
                    "timezone": str(now.tzinfo),
                }
            }
        return {"error": f"Unknown tool: {name}"}
    except ToolError as exc:
        return {"error": str(exc)}
    except Exception:  # never let a tool bug kill the voice session
        return {"error": "The tool failed unexpectedly."}

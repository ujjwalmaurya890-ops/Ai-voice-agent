import pytest

from campusvoice import tools
from campusvoice.tools import StudyStore, execute_tool


@pytest.fixture
def store(tmp_path):
    return StudyStore(tmp_path / "s.json")


def test_declarations_build_against_real_sdk_types():
    built = tools.build_tools()
    names = [d.name for d in built[0].function_declarations]
    assert names == [d["name"] for d in tools.TOOL_DECLARATIONS]


def test_tasks_sorted_by_due_date_and_persisted(tmp_path):
    s = StudyStore(tmp_path / "s.json")
    s.add_task("later", "2026-12-01")
    s.add_task("no date")
    s.add_task("sooner", "2026-11-01", "CS101")
    assert [t["title"] for t in s.list_tasks()] == ["sooner", "later", "no date"]
    reloaded = StudyStore(tmp_path / "s.json")
    assert len(reloaded.list_tasks()) == 3


def test_complete_task_hides_it_by_default(store):
    t = store.add_task("read ch 4")
    store.complete_task(t["id"])
    assert store.list_tasks() == []
    assert len(store.list_tasks(include_completed=True)) == 1


def test_bad_inputs_become_error_dicts_not_exceptions(store):
    assert "error" in execute_tool(store, "add_task", {"title": "  "})
    assert "error" in execute_tool(store, "add_task", {"title": "x", "due_date": "tomorrow"})
    assert "error" in execute_tool(store, "complete_task", {"task_id": "abc"})
    assert "error" in execute_tool(store, "complete_task", {"task_id": 999})
    assert "error" in execute_tool(store, "nope", {})
    assert "error" in execute_tool(store, "search_notes", {"query": ""})


def test_notes_search_ranks_by_matches(store):
    store.save_note("Mitosis", "Cell division in somatic cells", "BIO")
    store.save_note("Osmosis", "Water moves across a membrane; cell stays")
    hits = execute_tool(store, "search_notes", {"query": "cell division"})["result"]
    assert hits[0]["title"] == "Mitosis"


def test_datetime_tool_shape(store):
    result = execute_tool(store, "get_current_datetime", None)["result"]
    assert set(result) == {"date", "weekday", "time", "timezone"}


def test_corrupt_file_is_set_aside_not_fatal(tmp_path):
    path = tmp_path / "s.json"
    path.write_text("{not json", encoding="utf-8")
    s = StudyStore(path)
    assert s.list_tasks() == []
    assert (tmp_path / "s.corrupt.json").exists()
